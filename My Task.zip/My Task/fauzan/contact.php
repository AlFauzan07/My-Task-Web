<!DOCTYPE html>
<html>
<head>
    <title>SMK Programming>Contact</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li>
                    <a href="index.php">Start</a>
                </li>
                <li>
                    <a href="jurusan.php">Lainnya</a>
                </li>
                <li>
                    <a href="gallery.php">Gallery</a>
                </li>
                <li>
                    <a href="contact.php">Contact</a>
                </li>
                <li>
                    <a href="upload_file.php">Upload File</a>
                </li>
                <li>
                    <a href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
        <div class="header">
        <h1>Contact</h1> 
        <h1>SMK Programming</h1>
        <h3>Address & Contact Person</h3>
        </div><br>
        <table>
        <tr>
        <td rowspan="3">
        <img src="img/14.png" width="400px" style="margin-right: 25px"></td>
        <td><p style="margin-bottom: 80px">Jln. Hyper No. 110<br>Kec. Text Kab. Markup<br>Language 16804</p>
        </td>
        </tr>
        <tr>
            <td>
                <form action="#" method="get" >
                Name: <input type="text" name="name" style="margin-left: 24px" value="Your Name"/><br><br>
                Messages:
                <textarea name="komentar" rows="15" cols="25">
Ada keperluan apa?
                </textarea><br><br>
                <input type="submit" value="Kirim">
                </form>
            </td>
        </tr>
        </table>
    <p align="center">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua.<br> Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse
    cillum dolore eu fugiat nulla pariatur.<br> Excepteur sint occaecat cupidatat non
    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
</div>
    <div class="footer" align="center" style="margin-top: 50px">
    <a href="#" style="margin-right: 13px">link 1</a><b style="margin-right: 13px">|</b><a href="#" style="margin-right: 13px">link2</a><b style="margin-right: 13px">|</b><a href="#">link 3</a><br>
    <a href="#" style="margin-right: 13px">link 4</a><b style="margin-right: 13px">|</b><a href="#">link5</a>
        <p class="display-4">Copyright &copy; 2020 | SMK Programming</p>
    </div>
</body>
<script type="costum.js"></script>
</html>