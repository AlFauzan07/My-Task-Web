<?php
   session_start();
   if(isset($_SESSION['username'])) {
   header('location:index.php'); }
?>

<!DOCTYPE html>
<html>
<head>
    <title>SMK Programming</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <script type="text/javascript">
    function pemberithuan(){
      alert("Pendaftaran Berhasil");
    }
  </script>
</head>
<body>
        <div id="page-content">
            <div class="container"> 
            <div class="header">
                <div class="row">
                    <table>
                        <tr>
                            <td><img src="img/logo5.png" width="120px" style="margin-left: 25px" alt="..."></td>
                            <td><h1>SMK Programming</h1><p>Jln. Hyper No. 110<br>Kec. Text Kab. Markup<br>Language 16804</p></td>
                            <td></td>
                        </tr>
                        <tr>
                          <td colspan="3"><font color="white">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua.<br></font></td>
                        </tr>
                        </table>
              </div>
            </div><br>
<title>Form Register</title>
<div align='center'>
      <form action="prosesdaftar.php" method="post">
      <table>      
      <tr>
        <td colspan="2" align="center"><h1>New Register</h1></td>
      </tr>
      <tr>
        <td>Nama</td>
        <td> : <input name="username" type="text"></td>
      </tr>
      <tr>
        <td>Password</td>
        <td> : <input type="password" name="password"></td>
      </tr>
      <tr>
        <td>Alamat</td>
        <td> : <input name="alamat" type="text"></td>
      </tr>
      <tr>
        <td>Jenis Kelamin</td>
        <td> : <input type="radio" name="jenis_kelamin" value="Laki-laki">Laki-laki</td>
        <td><input type="radio" name="jenis_kelamin" value="Perempuan">Perempuan</td>
      </tr>
      <tr>
        <td>Jurusan</td>
        <td> : </td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="TP">TP</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="TKR">TKR</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="TSM">TSM</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="RPL">RPL</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="DKV">DKV</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="PS">PS</td>
      </tr>
      <tr>
        <td>Hobi</td>
        <td> : </td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Basket">Basket</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Futsal">Futsal</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Renang">Renang</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Bersepeda">Bersepeda</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Berwisata">Berwisata</td>
      </tr>
      <tr>
        <td colspan="2" align="right"><input value="Daftar" type="submit" onclick="pemberithuan()"> <input value="Batal" type="reset"></td>
      </tr>
      <tr>
        <td colspan="2" align="center">Have an Account? <a href="login.php"><b>Login</b></a></td>
      </tr>
      </table>
      </form>
</div>
<div class="footer" align="center" style="margin-top: 50px">
    <p class="display-4">Copyright &copy; 2020 | SMK Programming</p>
</div>
</body>
<script type="costum.js"></script>
</html>