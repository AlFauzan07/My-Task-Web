<!DOCTYPE html>
<html>
<head>
    <title>SMK Programming>Gallery</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li>
                    <a href="index.php">Start</a>
                </li>
                <li>
                    <a href="jurusan.php">Lainnya</a>
                </li>
                <li>
                    <a href="gallery.php">Gallery</a>
                </li>
                <li>
                    <a href="contact.php">Contact</a>
                </li>
                <li>
                    <a href="upload_file.php">Upload File</a>
                </li>
                <li>
                    <a href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
        <div id="page-content">
            <div class="container-fluid">
            <div class="header">
                <div class="row">
                    <div class="col-lg-12">
                        <h1>Gallery</h1>
                        <h1>SMK Programming</h1>
                        <h3>Foto-Foto</h3> 
                    </div>
                </div>
            </div>
            </div>
        </div>
        <br>
        <table>
        <tr>
            <td><img src="img/13.jpeg" width="625px"></td>
            <td><font color="white">qwer</font></td>
            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit,<br> sed do eiusmod
            tempor incididunt ut labore et dolore magna<br> aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo
            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse<br>
            cillum dolore eu fugiat nulla pariatur. Excepteur sint<br> occaecat cupidatat non
            proident, sunt in culpa qui officia<br> deserunt mollit anim id est laborum.</td>
        </tr>
        <tr>
            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit,<br> sed do eiusmod
            tempor incididunt ut labore et dolore magna<br> aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo
            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse<br>
            cillum dolore eu fugiat nulla pariatur. Excepteur sint<br> occaecat cupidatat non
            proident, sunt in culpa qui officia<br> deserunt mollit anim id est laborum.</td>
            <td><font color="white">qwer</font></td>
            <td><img src="img/8.jpeg" width="625px"></td>
        </tr>
        <tr>
            <td><img src="img/9.jpeg" width="625px"></td>
            <td><font color="white">qwer</font></td>
            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit,<br> sed do eiusmod
            tempor incididunt ut labore et dolore magna<br> aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo
            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse<br>
            cillum dolore eu fugiat nulla pariatur. Excepteur sint<br> occaecat cupidatat non
            proident, sunt in culpa qui officia<br> deserunt mollit anim id est laborum.</td>
        </tr>
        <tr>
            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit,<br> sed do eiusmod
            tempor incididunt ut labore et dolore magna<br> aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo
            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse<br>
            cillum dolore eu fugiat nulla pariatur. Excepteur sint<br> occaecat cupidatat non
            proident, sunt in culpa qui officia<br> deserunt mollit anim id est laborum.</td>
            <td><font color="white">qwer</font></td>
            <td><img src="img/10.jpeg" width="625px"></td>
        </tr>
        <tr>
            <td><img src="img/11.jpg" width="625px"></td>
            <td><font color="white">qwer</font></td>
            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit,<br> sed do eiusmod
            tempor incididunt ut labore et dolore magna<br> aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo
            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse<br>
            cillum dolore eu fugiat nulla pariatur. Excepteur sint<br> occaecat cupidatat non
            proident, sunt in culpa qui officia<br> deserunt mollit anim id est laborum.</td>
        </tr>
        <tr>
            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit,<br> sed do eiusmod
            tempor incididunt ut labore et dolore magna<br> aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo
            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse<br>
            cillum dolore eu fugiat nulla pariatur. Excepteur sint<br> occaecat cupidatat non
            proident, sunt in culpa qui officia<br> deserunt mollit anim id est laborum.</td>
            <td><font color="white">qwer</font></td>
            <td><img src="img/15.jpeg" width="625px"></td>
        </tr>
        </table>
    <div class="footer" align="center" style="margin-top: 50px">
    <a href="#" style="margin-right: 13px">link 1</a><b style="margin-right: 13px">|</b><a href="#" style="margin-right: 13px">link2</a><b style="margin-right: 13px">|</b><a href="#">link 3</a><br>
    <a href="#" style="margin-right: 13px">link 4</a><b style="margin-right: 13px">|</b><a href="#">link5</a>
        <p class="display-4">Copyright &copy; 2020 | SMK Programming</p>
    </div>
</body>
<script type="costum.js"></script>
</html>