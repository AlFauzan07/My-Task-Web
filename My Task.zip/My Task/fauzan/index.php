<?php
session_start();
if(!isset($_SESSION['username'])) {
    header('location:login.php'); 
} else { 
   $username = $_SESSION['username']; 
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>SMK Programming</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <script type="text/javascript">
    function pesan(){
        alert("Login Success!");
    }
    </script>
</head>
<body>
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li>
                    <a href="index.php">Start</a>
                </li>
                <li>
                    <a href="jurusan.php">Lainnya</a>
                </li>
                <li>
                    <a href="gallery.php">Gallery</a>
                </li>
                <li>
                    <a href="contact.php">Contact</a>
                </li>
                <li>
                    <a href="upload_file.php">Upload File</a>
                </li>
                <li>
                    <a href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
        <div id="page-content">
            <div class="container">	
            <div class="header">
                <div class="row">
                    <table>
                        <tr>
                            <td><img src="img/logo5.png" width="120px" style="margin-left: 25px" alt="..."></td>
                            <td><h1>SMK Programming</h1><p>Jln. Hyper No. 110<br>Kec. Text Kab. Markup<br>Language 16804</p></td>
                            <td></td>
                        </tr>
                        <tr>
                        	<td colspan="3"><font color="white">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua.<br></font></td>
                        </tr>
                        </table>
            	</div>
            </div><br>
            <img src="img/13.jpeg" style="margin-left: 320px">
            	<div class="container" align="center">
                        <table style="margin-top: 25px">
                        <tr>
                           <td colspan="2">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua.<br> Ut enim ad minim veniam,
                        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse
                        cillum dolore eu fugiat nulla pariatur.<br> Excepteur sint occaecat cupidatat non
                        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</td> 
                        </tr>
                        <tr><td><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                        quis<br/>nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                        cillum dolore eu<br> fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                    </p></td></tr>
                    </table>
                </div>

            <div class="container" style="margin-top: 100px">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 align="center">About</h1>
                        <h1 align="center">SMK Programming</h1><br><hr><hr>
                        <div class="container" align="center">
	                        <table>
	                        <tr>
	                            <td colspan="2">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
	                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,<br>
	                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
	                            consequat.</td>
	                        </tr>
	                        <tr>
	                            <td><font color="white">Lorem ipsum dolor sit amet, consectetur adipisicing elit<br></font></td>
	                            <td><font color="white">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod<br></font></td>
	                        </tr>
	                        <tr>
	                            <td>Lorem ipsum dolor sit amet, consectetur adipisicing<br> elit, sed do eiusmod
	                            tempor incididunt ut labore et<br> dolore magna aliqua. Ut enim ad minim veniam,
	                            quis<br> nostrud exercitation ullamco laboris nisi ut aliquip ex<br> ea commodo
	                            consequat.</td>
	                            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit,<br> sed do eiusmod
	                            tempor incididunt ut labore et dolore magna<br> aliqua. Ut enim ad minim veniam,
	                            quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo
	                            consequat.</td>
	                        </tr>
	                        <tr>
	                            <td rowspan="2">Lorem ipsum dolor sit amet, consectetur<br> adipisicing elit, sed do eiusmod
	                            tempor<br> incididunt ut labore et dolore magna<br>aliqua. Ut enim ad minim veniam,
	                            quis<br> nostrud exercitation ullamco laboris nisi<br> ut aliquip ex ea commodo
	                            consequat.<br> Duis aute irure dolor in reprehenderit in<br> voluptate velit esse
	                            cillum dolore eu fugiat<br> nulla pariatur. Excepteur sint occaecat<br> cupidatat non
	                            proident, sunt in culpa qui<br> officia deserunt mollit anim id est laborum.</td>
	                            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
	                            tempor incididunt ut labore et dolore<br> magna aliqua. Ut enim ad minim veniam,
	                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea<br> commodo
	                            consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
	                            cillum dolore eu fugiat nulla<br> pariatur. Excepteur sint occaecat cupidatat non
	                            proident, sunt in culpa qui officia deserunt mollit anim id est.</td>
	                        </tr>
	                        <tr>
	                            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
	                            tempor incididunt ut labore et dolore<br> magna aliqua. Ut enim ad minim veniam,
	                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea<br> commodo
	                            consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
	                            cillum dolore eu fugiat nulla<br> pariatur. Excepteur sint occaecat cupidatat non
	                            proident, sunt in culpa qui officia deserunt mollit anim id est.</td>
	                        </tr>
	                        </table>
	                    </div>
                    </div>
                </div>
            </div>    
                </div>
            </div>
        </div>
    </div>
<div class="footer" align="center" style="margin-top: 50px">
	<a href="#" style="margin-right: 13px">link 1</a><b style="margin-right: 13px">|</b><a href="#" style="margin-right: 13px">link2</a><b style="margin-right: 13px">|</b><a href="#">link 3</a><br>
	<a href="#" style="margin-right: 13px">link 4</a><b style="margin-right: 13px">|</b><a href="#">link5</a>
    <p class="display-4">Copyright &copy; 2020 | SMK Programming</p>
</div>
</body>
<script type="costum.js"></script>
</html>