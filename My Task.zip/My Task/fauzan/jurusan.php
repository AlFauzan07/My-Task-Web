<!DOCTYPE html>
<html>
<head>
	<title>SMK Programming>Lainnya</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li>
                    <a href="index.php">Start</a>
                </li>
                <li>
                    <a href="jurusan.php">Lainnya</a>
                </li>
                <li>
                    <a href="gallery.php">Gallery</a>
                </li>
                <li>
                    <a href="contact.php">Contact</a>
                </li>
                <li>
                    <a href="upload_file.php">Upload File</a>
                </li>
                <li>
                    <a href="logout.php">Logout</a>
                </li>
            </ul>
        </div>

        <div id="page-content">
            <div class="container-fluid">
            <div class="header">
                <div class="row">
                    <div class="col-lg-12">
                        <h1>Lainnya</h1>
                        <h1>SMK Programming</h1>
                        <h3>Aktifitas</h3>
                    </div>
                </div>
            </div>
            </div>
        </div>
        <div class="container" align="center">
                    <table>
                        <tr>
                            <td>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                        quis<br/>nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                        cillum dolore eu<br> fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p></td>
                        </tr>
                    </table>
                    <table border="1">
                        <tr>
                            <th>No</th>
                            <th>Kegiatan</th>
                            <th>Penjelasan</th>
                        </tr>
                        <tr>
                            <th>1</th>
                            <th><font color="white">hahh</font>Media Desain<font color="white">hahh</font></th>
                            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.<br> Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur.</td>
                        </tr>
                        <tr>
                            <th>2</th>
                            <th>Operator</th>
                            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.<br> Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur.</td>
                        </tr>
                        <tr>
                            <th>3</th>
                            <th>De-bugging</th>
                            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.<br> Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur.</td>
                        </tr>
                        <tr>
                            <th>4</th>
                            <th>Software</th>
                            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.<br> Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur.</td>
                        </tr>
                        <tr>
                            <th>5</th>
                            <th>Hardware</th>
                            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.<br> Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur.</td>
                        </tr>
                        <tr>
                            <th>6</th>
                            <th>Server</th>
                            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.<br> Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur.</td>
                        </tr>
                        <tr>
                            <th>7</th>
                            <th>Modifier</th>
                            <td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                            tempor incididunt ut labore et dolore magna aliqua.<br> Ut enim ad minim veniam,
                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                            consequat.<br> Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur.</td>
                        </tr>
                    </table><br>
                    <table>
                        <tr>
                            <td>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                        quis<br/>nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                        cillum dolore eu<br> fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p></td>
                        </tr>
                    </table>
        </div>
<div class="footer" align="center" style="margin-top: 50px">
    <a href="#" style="margin-right: 13px">link 1</a><b style="margin-right: 13px">|</b><a href="#" style="margin-right: 13px">link2</a><b style="margin-right: 13px">|</b><a href="#">link 3</a><br>
    <a href="#" style="margin-right: 13px">link 4</a><b style="margin-right: 13px">|</b><a href="#">link5</a>
    <p class="display-4">Copyright &copy; 2020 | SMK Programming</p>
</div>
</body>
<script type="costum.js"></script>
</html>