<!DOCTYPE html>
<html>
<head>
    <title>SMK Programming</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <script type="text/javascript">
    function pesan(){
      alert("Login Fail!");
    }
  </script>
</head>
<body>
        <div id="page-content">
            <div class="container"> 
            <div class="header">
                <div class="row">
                    <table>
                        <tr>
                            <td><img src="img/logo5.png" width="120px" style="margin-left: 25px" alt="..."></td>
                            <td><h1>SMK Programming</h1><p>Jln. Hyper No. 110<br>Kec. Text Kab. Markup<br>Language 16804</p></td>
                            <td></td>
                        </tr>
                        <tr>
                          <td colspan="3"><font color="white">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua.<br></font></td>
                        </tr>
                        </table>
              </div>
            </div><br>
<?php
   session_start();
   if(isset($_SESSION['username'])) {
   header('location:index.php'); }
   require_once("koneksi.php");
?>

<title>Login</title>
<div align='center'>
  <form action="proseslogin.php" method="post">
  <h1>Login</h1>
  <table>
  <tbody>
  <tr><td>Username</td><td>: <input name="username" type="text"></td></tr>
  <tr><td>Password</td><td>: <input name="password" type="password"></td></tr>
  <tr><td colspan="2" align="right"><input value="Login" type="submit"> <input value="Batal" type="reset"></td></tr>
  <tr><td colspan="2" align="center">Don't have an account? <a href="daftar.php"><b>Register</b></a></td></tr>
  </tbody>
  </table>
  </form>
</div>
<div class="footer" align="center" style="margin-top: 50px">
    <p class="display-4">Copyright &copy; 2020 | SMK Programming</p>
</div>
</body>
<script type="costum.js"></script>
</html>