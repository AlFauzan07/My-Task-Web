<?php
   session_start();
   session_destroy();
?>

<div align="center">
  <h2>You Successfully Logout</h2>
  Click <a href="login.php">Here</a> to Login
</div>