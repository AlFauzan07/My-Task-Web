<?php
include ('koneksi.php');
include ('action_upload.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>SMK Programming</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li>
                    <a href="index.php">Start</a>
                </li>
                <li>
                    <a href="jurusan.php">Lainnya</a>
                </li>
                <li>
                    <a href="gallery.php">Gallery</a>
                </li>
                <li>
                    <a href="contact.php">Contact</a>
                </li>
                <li>
                    <a href="upload_file.php">Upload File</a>
                </li>
                <li>
                    <a href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
        <div id="page-content">
            <div class="container"> 
            <div class="header">
                <div class="row">
                    <table>
                        <tr>
                            <td><img src="img/logo5.png" width="120px" style="margin-left: 25px" alt="..."></td>
                            <td><h1>SMK Programming</h1><p>Jln. Hyper No. 110<br>Kec. Text Kab. Markup<br>Language 16804</p></td>
                            <td></td>
                        </tr>
                        <tr>
                          <td colspan="3"><font color="white">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua.<br></font></td>
                        </tr>
                        </table>
              </div>
            </div><br>
            <div class="container">
              <div class="content">
                <form method="post" enctype="multipart/form-data" action="">
                  <table align="center">
                    <tr>
                      <td colspan="2" height="25" class="title">Form Upload File</td>
                    </tr>
                    <tr>
                      <td width="100">File</td>
                      <td><input type="file" name="data_upload"/></td>
                    </tr>
                    <tr>
                      <td width="100" valign="top">keterangan</td>
                      <td><textarea name="keterangan" cols="30" rows="3"></textarea></td>
                    </tr>
                    <tr>
                      <td></td>
                      <td><input type="submit" name="btnUpload" value="Upload"/></td>
                    </tr>
                  </table>
                </form>
              </div>
            </div>
            <div class="footer" align="center" style="margin-top: 50px">
                <p class="display-4">Copyright &copy; 2020 | SMK Programming</p>
            </div>
            </body>
            <script type="costum.js"></script>
            </html>