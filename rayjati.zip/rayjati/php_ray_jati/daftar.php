<!DOCTYPE html>
<html>
<head>
	<title>ray jati</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" href="js/jquery.js"></script>
	<script type="text/javascript" href="js/bootstrap.js"></script>
	<meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	
</head>
<body>
  <style>
  body {

  background-image: url(foto/bb.jpeg);
  background-size: cover;

}

.dd {
  position: relative;
  display: inline-block;
}

.dd-btn {

padding: 10px;
text-align: center;
background: #000000;
border:none;
width: 100px;
color: #f8f9f9;

}

.dd-content {
  position: absolute;
  width: 100%;
  box-shadow: 0 18px 36px rgba(0,0,0,0.30), 0 14px 11px rgba(0,0,0,0.22);
  opacity: 0;
  transition: opacity 1s;

}

.dd:hover > .dd-content {
  opacity: 1;

}

.dd-content > a {
  display: block;
  padding: 15px;
  text-decoration: none;
  color: black;
}
</style>



<div class="container" align="center">
	<div id="header" style="border: 3px solid #000000;  ">
		<div class="container">


			<img src="foto/3.png" width="80px" height="70px" style="float: left;"">
			<img src="foto/3.png" width="80px" height="70px" style="float: right;"">
			<h4 align="center">Smk Negri 12 Bandung</h4>
				<h4 align="center">jl.soekarno hatta</h4>
					<h4 align="center">@Smk 12 bandung
			</div>
		</div>
	<hr>
</div>




<nav class=”vertikal”>
<div class="menu-malasngoding"> 



<div class="list group" align="right" style="float: right;">

  <div class="container" align="right">
      <div class="dd">
    <button class="dd-btn">select</button>
    <div class="dd-content">
       <a href="index.php">home</a>
       <a href="galeri.php">galery</a>
        <a href="profil.php">profil</a>
        <a href="login.php">login</a>
      </div>
    </div>
  </div>
</div>
</div>
</nav>
<title>Form Register</title>
<div align='center'>
      <form action="prosesdaftar.php" method="post">
      <table>      
      <tr>
        <td colspan="2" align="center"><h1>New Register</h1></td>
      </tr>
      <tr>
        <td>Nama</td>
        <td> : <input name="username" type="text"></td>
      </tr>
      <tr>
        <td>Password</td>
        <td> : <input type="password" name="password"></td>
      </tr>
      <tr>
        <td>Alamat</td>
        <td> : <input name="alamat" type="text"></td>
      </tr>
      <tr>
        <td>Jenis Kelamin</td>
        <td> : <input type="radio" name="jenis_kelamin" value="Laki-laki">Laki-laki</td>
        <td><input type="radio" name="jenis_kelamin" value="Perempuan">Perempuan</td>
      </tr>
      <tr>
        <td>Jurusan</td>
        <td> : </td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="TP">TP</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="TKR">TKR</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="TSM">TSM</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="RPL">RPL</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="DKV">DKV</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="PS">PS</td>
      </tr>
      <tr>
        <td>Hobi</td>
        <td> : </td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Basket">Basket</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Futsal">Futsal</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Renang">Renang</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Bersepeda">Bersepeda</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Berwisata">Berwisata</td>
      </tr>
      <tr>
        <td colspan="2" align="right"><input value="Daftar" type="submit" onclick="pemberithuan()"> <input value="Batal" type="reset"></td>
      </tr>
      <tr>
        <td colspan="2" align="center">Have an Account? <a href="login.php"><b>Login</b></a></td>
      </tr>
      </table>
      </form>
</div>