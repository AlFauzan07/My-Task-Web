<!DOCTYPE html>
<html>
<head>
  <title>ray jati</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <script type="text/javascript" href="js/jquery.js"></script>
  <script type="text/javascript" href="js/bootstrap.js"></script>
  <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
  
</head>
<body>
   <style>
  body {

  background-image: url(foto/bb.jpeg);
  background-size: cover;

}

.dd {
  position: relative;
  display: inline-block;
}

.dd-btn {

padding: 10px;
text-align: center;
background: #000000;
border:none;
width: 100px;
color: #f8f9f9;

}

.dd-content {
  position: absolute;
  width: 100%;
  box-shadow: 0 18px 36px rgba(0,0,0,0.30), 0 14px 11px rgba(0,0,0,0.22);
  opacity: 0;
  transition: opacity 1s;

}

.dd:hover > .dd-content {
  opacity: 1;

}

.dd-content > a {
  display: block;
  padding: 15px;
  text-decoration: none;
  color: black;
}
</style>

<div class="container" align="center">
  <div id="header" style="border: 3px solid #000000;  ">
    <div class="container">
    
      <img src="foto/3.png" width="80px" height="70px" style="float: left;"">
      <img src="foto/3.png" width="80px" height="70px" style="float: right;"">
      <h4 align="center">Smk Negri 12 Bandung</h4>
        <h4 align="center">jl.soekarno hatta</h4>
          <h4 align="center">@Smk 12 bandung
      </div>
      </div>
    </div>
  <hr>
</div>




<nav class=”vertikal”>

<div class="list group" align="right" style="float: right;">

 <div class="container" align="right">
      <div class="dd">
    <button class="dd-btn">select</button>
    <div class="dd-content">
      <a href="index.php">home</a>
       <a href="galeri.php">galery</a>
        <a href="profil.php">profil</a>
        <a href="login.php">login</a>
        <a href="file_upload.php">File Upload</a>
      <a href="logout.php">Logout</a>
      </div>
    </div>

        </ul>
          </div>
            </div>



            
          <div class="container" align="right">
            
 <div class="image-container">
 <img src="foto/3.png" width="500" height="400">
 <p class="image-description">logo smk 12</p>
 </div>

 <div class="image-container">
 <img src="foto/5.jpeg"  width="500" height="400">
 <p class="image-description">halaman depan smk</p>
 </div>

 <div class="image-container">
 <img src="foto/4.jpg"  width="500" height="400">
 <p class="image-description">hasil bikin pesawat</p>
 </div>


 <div class="image-container">
 <img src="foto/6.jpg"  width="500" height="400">
 <p class="image-description">pesawat jabiru</p>
 </div>


 <div class="image-container">
 <img src="foto/7.jpg"  width="500" height="400">
 <p class="image-description">foto bersama</p>
 </div>


      </div>
    </div>
  </div>
 <br>
   
    <br> 
    <br>
    <br>
     <br>
    <br>
    <br>

  <footer>
    <div id="header" style="border: 3px solid #dedede; "> 
       <footer style="background: black; color: white; height: 200px; padding: 15px"><p align="center">

  <div class="addres-area black-bg section-padding">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-md-4">
                    <div class="single-address text-center">
                        <div class="addres-icon">
                           
                        </div>
                        <h3>lokasi kami</h3>
                        <p>jl.soekarno hatta<br>
                            no.115 bandung</p>
                    </div>
                </div>
                <div class="col-xl-4 col-md-4">
                    <div class="single-address text-center">
                        <div class="addres-icon">
                            
                        </div>
                        <h3>buka dari jam</h3>
                        <p> (9.00-20.00) <br>
                            Senin-jumat 
                    </div>
                </div>
                <div class="col-xl-4 col-md-4">
                    <div class="single-address text-center">
                        <div class="addres-icon">
                           
                        </div>
                        <h3>kirim pesan di</h3>
                        <p>rayjati86@gmail.com <br>
                            088 2206 7810</p>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
  

   <p align="center">Copyright &copy;<script>document.write(new Date().getFullYear());</script> smk lugina rck | bandung jawa barat<i class="fa fa-heart-o" aria-hidden="true"></i> </p>
</footer>    

   

   
</div>
</body>
</html>    
