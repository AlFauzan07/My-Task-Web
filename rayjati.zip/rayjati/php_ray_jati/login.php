<!DOCTYPE html>
<html>
<head>
	<title>ray jati</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" href="js/jquery.js"></script>
	<script type="text/javascript" href="js/bootstrap.js"></script>
	<meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

	
</head>
<body>
  <style>
  body {

  background-image: url(foto/bb.jpeg);
  background-size: cover;

}

.dd {
  position: relative;
  display: inline-block;
}

.dd-btn {

padding: 10px;
text-align: center;
background: #000000;
border:none;
width: 100px;
color: #f8f9f9;

}

.dd-content {
  position: absolute;
  width: 100%;
  box-shadow: 0 18px 36px rgba(0,0,0,0.30), 0 14px 11px rgba(0,0,0,0.22);
  opacity: 0;
  transition: opacity 1s;

}

.dd:hover > .dd-content {
  opacity: 1;

}

.dd-content > a {
  display: block;
  padding: 15px;
  text-decoration: none;
  color: black;
}
</style>



<div class="container" align="center">
	<div id="header" style="border: 3px solid #000000;  ">
		<div class="container">


			<img src="foto/3.png" width="80px" height="70px" style="float: left;"">
			<img src="foto/3.png" width="80px" height="70px" style="float: right;"">
			<h4 align="center">Smk Negri 12 Bandung</h4>
				<h4 align="center">jl.soekarno hatta</h4>
					<h4 align="center">@Smk 12 bandung</h4>
			</div>
		</div>
	<hr>
</div>




<nav class=”vertikal”>
<div class="menu-malasngoding"> 



<div class="list group" align="right" style="float: right;">

  <div class="container" align="right">
      <div class="dd">
    <button class="dd-btn">select</button>
    <div class="dd-content">
       <a href="index.php">home</a>
       <a href="galeri.php">galery</a>
        <a href="profil.php">profil</a>
        <a href="login.php">login</a>
        <a href="file_upload.php">File Upload</a>
      <a href="logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>
</div>
</nav>
<div class="container">
  <div align='center'>
    <form action="proseslogin.php" method="post">
    <h1>Login</h1>
    <table>
    <tbody>
    <tr><td>Username</td><td>: <input name="username" type="text"></td></tr>
    <tr><td>Password</td><td>: <input name="password" type="password"></td></tr>
    <tr><td colspan="2" align="right"><input value="Login" type="submit"> <input value="Batal" type="reset"></td></tr>
    <tr><td colspan="2" align="center">Don't have an account? <a href="daftar.php"><b>Register</b></a></td></tr>
    </tbody>
    </table>
    </form>
  </div>
</div>